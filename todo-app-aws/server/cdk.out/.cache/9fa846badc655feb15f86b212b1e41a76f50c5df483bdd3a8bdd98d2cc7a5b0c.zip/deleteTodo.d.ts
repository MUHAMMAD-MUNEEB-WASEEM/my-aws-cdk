declare function deleteTodo(id: string): Promise<string | null>;
export default deleteTodo;

type id = {
    id: String;
}
export default id;
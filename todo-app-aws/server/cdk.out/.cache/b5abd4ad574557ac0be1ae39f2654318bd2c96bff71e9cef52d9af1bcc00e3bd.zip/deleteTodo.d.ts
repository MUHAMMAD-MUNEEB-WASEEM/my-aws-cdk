declare function deleteTodo(id: String): Promise<String | null>;
export default deleteTodo;

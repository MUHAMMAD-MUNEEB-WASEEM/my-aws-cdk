type Todo = {
    id: string;
    title: string;

}
export default Todo;
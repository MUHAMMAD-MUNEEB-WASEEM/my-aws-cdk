declare function deleteTodo(id: string): Promise<"Delte todo" | null>;
export default deleteTodo;

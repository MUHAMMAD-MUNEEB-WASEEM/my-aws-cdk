import Todo from './todo';
declare function addTodo(todo: Todo): Promise<Todo | null>;
export default addTodo;

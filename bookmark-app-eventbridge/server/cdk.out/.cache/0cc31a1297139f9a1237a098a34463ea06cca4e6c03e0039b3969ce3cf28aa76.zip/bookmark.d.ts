declare type Bookmark = {
    id: String;
    title: String;
    url: String;
};
export default Bookmark;

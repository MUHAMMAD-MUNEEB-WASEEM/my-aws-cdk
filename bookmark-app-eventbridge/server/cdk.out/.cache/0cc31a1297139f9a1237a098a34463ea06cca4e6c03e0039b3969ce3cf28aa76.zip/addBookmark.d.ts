import Bookmark from './bookmark';
declare function addBookmark(bookmark: Bookmark): Promise<Bookmark | null>;
export default addBookmark;

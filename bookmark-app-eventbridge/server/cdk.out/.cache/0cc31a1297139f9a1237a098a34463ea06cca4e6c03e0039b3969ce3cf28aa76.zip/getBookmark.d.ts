declare function getBookmark(): Promise<any>;
export default getBookmark;
